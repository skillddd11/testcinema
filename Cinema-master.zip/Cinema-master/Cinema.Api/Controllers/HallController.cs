using Cinema.Api.DTOs;
using Cinema.Core.Interfaces;
using Cinema.Core.WorkModel;
using DataAccess.Models;
using Microsoft.AspNetCore.Mvc;

namespace Cinema.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class HallController : Controller
{
    public HallController(IUnitOfWork workModel, IStorageService storageService)
    {
        WorkModel = workModel;
        StorageService = storageService;
    }

    private IUnitOfWork WorkModel { get; }
    private IStorageService StorageService { get; }

    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var halls = await WorkModel.HallRepository
            .GetAllAsync();

        return Json(halls);
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id)
    {
        var hall = await WorkModel.HallRepository
            .GetByIdAsync(id);

        if (hall is null)
            return NotFound("Hall not found");

        return Json(hall);
    }

    [HttpPost]
    public async Task<IActionResult> Add([FromForm] HallDto dto)
    {
        var hall = new Hall
        {
            Number = dto.Number,
            Capacity = dto.Capacity,
            PriceId = dto.PriceId
        };

        if (dto.Image is not null)
        {
            var result = await StorageService.UploadAsyncToStorage(dto.Image);

            if (result.Error || result.Blob is null)
            {
                return BadRequest(result.Status);
            }

            hall.Url = result.Blob.Uri!;
            hall.BlobName = result.Blob.Name!;
        }

        await WorkModel.HallRepository.AddAsync(hall);
        await WorkModel.SaveChangesAsync();

        return Ok(hall);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update([FromRoute] int id, [FromForm] HallDto dto)
    {
        var hall = await WorkModel.HallRepository
            .GetByIdAsync(id);

        if (hall is null)
            return NotFound("Hall not found");

        hall.Number = dto.Number;
        hall.Capacity = dto.Capacity;
        hall.PriceId = dto.PriceId;

        if (dto.Image is not null)
        {
            var result = await StorageService.UploadAsyncToStorage(dto.Image);

            if (result.Error || result.Blob is null)
            {
                return BadRequest(result.Status);
            }

            hall.Url = result.Blob.Uri!;
            hall.BlobName = result.Blob.Name!;
        }

        await WorkModel.SaveChangesAsync();

        return Ok(hall);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete([FromRoute] int id)
    {
        var hall = await WorkModel.HallRepository
            .GetByIdAsync(id);

        if (hall is null)
            return NotFound("Hall not found");

        if (hall.BlobName is not null)
            await StorageService.DeleteAsyncFromStorage(hall.BlobName);

        await WorkModel.HallRepository.DeleteAsync(hall);
        await WorkModel.SaveChangesAsync();

        return Ok();
    }
}
