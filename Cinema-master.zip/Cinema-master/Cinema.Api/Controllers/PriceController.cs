using Cinema.Api.DTOs;
using Cinema.Core.WorkModel;
using DataAccess.Models;
using Microsoft.AspNetCore.Mvc;

namespace Cinema.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PriceController : Controller
{
    private IUnitOfWork WorkModel { get; }

    public PriceController(IUnitOfWork workModel)
    {
        WorkModel = workModel;
    }

    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var prices = await WorkModel.PriceRepository
            .GetAllAsync();

        return Json(prices);
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id)
    {
        var price = await WorkModel.PriceRepository
            .GetByIdAsync(id);

        if (price is null)
            return NotFound("Price not found");

        return Json(price);
    }

    [HttpPost]
    public async Task<IActionResult> Add([FromBody] PriceDto priceDto)
    {
        var price = new Price
        {
            Name = priceDto.Name,
            PricePer2Hours = priceDto.PricePer2Hours,
            PricePer4Hours = priceDto.PricePer4Hours,
            PricePer6Hours = priceDto.PricePer6Hours,
            PricePer2HoursEvening = priceDto.PricePer2HoursEvening,
            PricePer4HoursEvening = priceDto.PricePer4HoursEvening,
            PricePer6HoursEvening = priceDto.PricePer6HoursEvening
        };

        await WorkModel.PriceRepository.AddAsync(price);
        await WorkModel.SaveChangesAsync();

        return Ok(price);
    }

    [HttpPut]
    public async Task<IActionResult> Update([FromBody] PriceDto priceDto)
    {
        var price = await WorkModel.PriceRepository
            .GetByIdAsync(priceDto.Id);

        if (price is null)
            return NotFound("Price not found");

        price.Name = priceDto.Name;
        price.PricePer2Hours = priceDto.PricePer2Hours;
        price.PricePer4Hours = priceDto.PricePer4Hours;
        price.PricePer6Hours = priceDto.PricePer6Hours;
        price.PricePer2HoursEvening = priceDto.PricePer2HoursEvening;
        price.PricePer4HoursEvening = priceDto.PricePer4HoursEvening;
        price.PricePer6HoursEvening = priceDto.PricePer6HoursEvening;

        await WorkModel.PriceRepository.UpdateAsync(price);
        await WorkModel.SaveChangesAsync();

        return Ok(price);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete([FromRoute] int id)
    {
        var price = await WorkModel.PriceRepository
            .GetByIdAsync(id);

        if (price is null)
            return NotFound("Price not found");

        await WorkModel.PriceRepository.DeleteAsync(price);
        await WorkModel.SaveChangesAsync();

        return Ok();
    }
}
