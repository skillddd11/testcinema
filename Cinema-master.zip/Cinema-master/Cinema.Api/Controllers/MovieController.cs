using Cinema.Api.DTOs;
using Cinema.Core.Interfaces;
using Cinema.Core.WorkModel;
using DataAccess.Models;
using Microsoft.AspNetCore.Mvc;

namespace Cinema.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class MovieController : Controller
{
    public MovieController(IUnitOfWork workModel, IStorageService storageService)
    {
        WorkModel = workModel;
        StorageService = storageService;
    }

    private IUnitOfWork WorkModel { get; }
    private IStorageService StorageService { get; }

    [HttpGet]
    public async Task<IActionResult> GetMovies()
    {
        var movies = await WorkModel.MovieRepository.GetMoviesAsync();

        if (movies is null)
            return NotFound();

        return Ok(movies);
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetMovieById([FromRoute] int id)
    {
        var movie = await WorkModel.MovieRepository.GetMovieByIdAsync(id);

        if (movie is null)
            return NotFound();

        return Ok(movie);
    }

    [HttpPost]
    public async Task<IActionResult> CreateMovie([FromForm] MovieDto movieDto)
    {
        var movie = new Movie
        {
            Title = movieDto.Title,
            Description = movieDto.Description,
            StartDate = movieDto.StartDate,
            EndDate = movieDto.EndDate,
            Premiere = movieDto.Premiere,
            BigImage = movieDto.BigImage,
            Avatar = movieDto.Avatar,
            Country = movieDto.Country,
            Genre = movieDto.Genre,
            Duration = movieDto.Duration,
            Director = movieDto.Director,
            Actors = movieDto.Actors,
            Scenarist = movieDto.Scenarist,
            AgeFrom = movieDto.AgeFrom
        };

        if (movieDto.Image is not null)
        {
            var result = await StorageService.UploadAsyncToStorage(movieDto.Image);

            if (result.Error || result.Blob is null)
            {
                return BadRequest(result.Status);
            }

            movie.ImageUrl = result.Blob.Uri;
            movie.BlobName = result.Blob.Name;
        }

        await WorkModel.MovieRepository.AddAsync(movie);
        await WorkModel.SaveChangesAsync();

        return Ok(movie);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> UpdateMovie([FromRoute] int id, [FromForm] MovieDto movieDto)
    {
        var movie = await WorkModel.MovieRepository.GetMovieByIdAsync(id);

        if (movie is null)
            return NotFound();

        movie.Title = movieDto.Title;
        movie.Description = movieDto.Description;
        movie.StartDate = movieDto.StartDate;
        movie.EndDate = movieDto.EndDate;
        movie.Premiere = movieDto.Premiere;
        movie.BigImage = movieDto.BigImage;
        movie.Avatar = movieDto.Avatar;
        movie.Country = movieDto.Country;
        movie.Genre = movieDto.Genre;
        movie.Duration = movieDto.Duration;
        movie.Director = movieDto.Director;
        movie.Actors = movieDto.Actors;
        movie.Scenarist = movieDto.Scenarist;
        movie.AgeFrom = movieDto.AgeFrom;

        if (movieDto.Image is not null)
        {
            if (movie.BlobName is not null)
                await StorageService.DeleteAsyncFromStorage(movie.BlobName);

            var result = await StorageService.UploadAsyncToStorage(movieDto.Image);

            if (result.Error || result.Blob is null)
                return BadRequest(result.Status);

            movie.ImageUrl = result.Blob.Uri;
            movie.BlobName = result.Blob.Name;
        }

        await WorkModel.MovieRepository.UpdateAsync(movie);
        await WorkModel.SaveChangesAsync();

        return Ok(movie);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> DeleteMovie([FromRoute] int id)
    {
        var movie = await WorkModel.MovieRepository.GetMovieByIdAsync(id);

        if (movie is null)
            return NotFound();

        if (movie.BlobName is not null)
            await StorageService.DeleteAsyncFromStorage(movie.BlobName);

        await WorkModel.MovieRepository.DeleteAsync(movie);
        await WorkModel.SaveChangesAsync();

        return Ok(movie);
    }
}
