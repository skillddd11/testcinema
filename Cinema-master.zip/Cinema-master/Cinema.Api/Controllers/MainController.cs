using Cinema.Api.DTOs;
using Cinema.Core.WorkModel;
using DataAccess.Models;
using Microsoft.AspNetCore.Mvc;

namespace Cinema.Api.Controllers;

[ApiController]
[Route("api/[controller]/[action]")]
public class MainController : Controller
{
    private IUnitOfWork WorkModel { get; }

    public MainController(IUnitOfWork workModel)
    {
        WorkModel = workModel;
    }

    [HttpGet]
    [ActionName("page")]
    public async Task<IActionResult> Get()
    {
        var movies = await WorkModel.MovieRepository
            .GetActualMoviesAsync();

        return Ok(movies);
    }

    [HttpGet]
    [ActionName("prices")]
    public async Task<IActionResult> GetPrices()
    {
        var halls = await WorkModel.HallRepository
            .GetAllAsync();

        return Ok(halls);
    }

    [HttpGet("{id:int}")]
    [ActionName("payment")]
    public async Task<IActionResult> GetPayment([FromRoute] int id)
    {
        var price = await WorkModel.HallRepository
            .GetPriceInfoAsync(id);

        if (price is null)
            return NotFound("Price not found");

        var reservedDates = price.Hall.Reservations
            .Select(r => new { Date = r.ReservationDate, r.Hour, Hours = r.ReservationHours })
            .Distinct()
            .OrderBy(d => d.Date)
            .ToList();

        price.Hall.Reservations = new List<Reservation>();

        var result = new
        {
            price,
            reservedDates,
            films = await WorkModel.MovieRepository
                .GetActualMoviesAsync()
        };

        return Json(result);
    }

    [HttpPost]
    [ActionName("reservation")]
    public async Task<IActionResult> MakeReservation([FromBody] ReservationDto reservationDto)
    {
        var price = await WorkModel.HallRepository
            .GetPriceInfoAsync(reservationDto.PriceId);

        if (price is null)
            return NotFound("Price not found");

        if (price.Hall.Reservations.Any(r =>
            {
                if (r.ReservationDate.Date != reservationDto.Date.Date)
                    return false;

                if (r.Hour > reservationDto.Hour)
                    return r.Hour > reservationDto.Hour + reservationDto.ReservationHours;

                return r.Hour + r.ReservationHours < reservationDto.Hour;
            }))
            return BadRequest("На текущую дату и время уже есть бронь");

        var reservation = new Reservation
        {
            ReservationDate = reservationDto.Date,
            Hall = price.Hall,
            Name = reservationDto.Name,
            Email = reservationDto.Email,
            Hour = reservationDto.Hour,
            Price = reservationDto.Price,
            MovieId = reservationDto.MovieId,
            Bar = reservationDto.Bar,
            Evening = reservationDto.Evening,
            ReservationHours = reservationDto.ReservationHours
        };

        await WorkModel.HallRepository.AddReservationAsync(reservation);
        await WorkModel.SaveChangesAsync();

        return Json("Бронь успешно создана");
    }

    [HttpPost]
    [ActionName("reservations")]
    public async Task<IActionResult> GetReservations([FromBody] SearchDto searchDto)
    {
        var reservations = await WorkModel.PriceRepository
            .GetReservationsAsync(r => r.ReservationDate.Date == searchDto.Date.Date);

        if (searchDto.Email is not null)
            reservations = reservations.Where(r => r.Email.ToLower().Contains(searchDto.Email.ToLower()));

        if (searchDto.Name is not null)
            reservations = reservations.Where(r => r.Name.ToLower().Contains(searchDto.Name.ToLower()));

        return Json(reservations);
    }
}
