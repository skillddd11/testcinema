namespace Cinema.Api.DTOs;

public class SearchDto
{
    public string? Name { get; set; }
    public string? Email { get; set; }
    public DateTime Date { get; set; } = DateTime.Today;
}
