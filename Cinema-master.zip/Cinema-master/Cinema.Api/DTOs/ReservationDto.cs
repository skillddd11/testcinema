namespace Cinema.Api.DTOs;

public class ReservationDto
{
    public string Name { get; set; } = null!;
    public string Email { get; set; } = null!;
    public int MovieId { get; set; }
    public DateTime Date { get; set; }
    public int Hour { get; set; }
    public int ReservationHours { get; set; }
    public bool Evening { get; set; }
    public bool Bar { get; set; }
    public int Price { get; set; }
    public int PriceId { get; set; }
}
