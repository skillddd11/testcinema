namespace Cinema.Api.DTOs;

public class MovieDto
{
    public string Title { get; set; } = null!;
    public string Description { get; set; } = null!;

    public bool Premiere { get; set; }
    public bool BigImage { get; set; }
    public bool Avatar { get; set; }

    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }

    public IFormFile? Image { get; set; } = null!;

    public string Country { get; set; } = null!;
    public string Genre { get; set; } = null!;
    public string Director { get; set; } = null!;
    public string Actors { get; set; } = null!;
    public string Duration { get; set; } = null!;
    public string Scenarist { get; set; } = null!;
    public string AgeFrom { get; set; } = null!;
}
