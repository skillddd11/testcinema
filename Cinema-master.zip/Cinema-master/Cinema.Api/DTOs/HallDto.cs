namespace Cinema.Api.DTOs;

public class HallDto
{
    public int Number { get; set; }
    public int Capacity { get; set; }
    public int PriceId { get; set; }

    public IFormFile? Image { get; set; }
}
