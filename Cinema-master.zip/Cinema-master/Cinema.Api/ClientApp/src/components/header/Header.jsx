import styles from "./header.module.css";
import logo from "../../images/logo.png";
import {useEffect, useState} from "react";
import {useNavigate} from "react-router-dom";

const Header = ({navigation, change, onClick}) => {
    const [click, setClick] = useState(change);
    const navigate = useNavigate();

    const menuItems = ["О кинотеатре", "Услуги", "Ресторан", "Галерея", "Контакты"];

    useEffect(() => {
        setClick(change);
    }, [change]);

    const handleClick = (index) => {
        setClick(index);
        onClick(index);
    }

    return (
        <>
            <div className={styles.wrap}>
                <header className={styles.header}>
                    <div className={styles.wrapper}>
                        <img className={styles.logo} src={logo} alt={"logo"} onClick={() => navigate("/")}/>
                        <div className={styles.menuItem} onClick={() => navigate("/about")}>о кинотеатре</div>
                        <div className={styles.menuItem} onClick={() => navigate("/prices")}>цены</div>
                    </div>
                    <div>
                        <div className={styles.menuItem} onClick={() => window.open('https://t.me')}>Поддержка</div>
                    </div>
                </header>
                {
                    navigation &&
                    <ul className={styles.navigation}>
                        {
                            menuItems.map((item, index) => {
                                return (
                                    <li key={index}
                                        className={`${styles.navigationItem} ${click === index ? styles.active : ""}`}
                                        onClick={() => handleClick(index)}>
                                        {item}
                                    </li>
                                )
                            })
                        }
                    </ul>
                }
            </div>
        </>
    )
}

export default Header;