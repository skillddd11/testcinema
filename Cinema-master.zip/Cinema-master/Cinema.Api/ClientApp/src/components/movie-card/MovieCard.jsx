import styles from './movie-card.module.css';
import {useNavigate} from "react-router-dom";

const MovieCard = ({name, date, link, big}) => {
    const navigate = useNavigate();

    return (
        <>
            <div className={`${styles.wrapper} ${big && styles.big}`} onClick={() => navigate('/prices')}>
                <div className={styles.background} style={{backgroundImage: `url(${link})`}}>
                    <div className={styles.title}>
                        {name}
                    </div>
                    <div className={styles.date}>
                        {date}
                    </div>
                </div>
            </div>
        </>
    )
}

export default MovieCard;