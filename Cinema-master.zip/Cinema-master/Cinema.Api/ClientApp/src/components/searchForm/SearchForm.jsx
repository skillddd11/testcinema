import React, {useState} from 'react';
import {Form, Button, Col, Row} from 'react-bootstrap';

const SearchForm = ({onSearch}) => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [selectedDate, setSelectedDate] = useState(new Date());

    const handleSearch = () => {
        const searchParams = {
            name,
            email,
            date: selectedDate,
        };

        onSearch(searchParams);
    };

    return (
        <Form className={'mb-5'}>
            <Form.Group as={Row} className="mb-3">
                <Col>
                    <Form.Label>Имя</Form.Label>
                    <Form.Control
                        type="text"
                        placeholder="Введите имя"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                    />
                </Col>

                <Col>
                    <Form.Label>Email</Form.Label>
                    <Form.Control
                        type="email"
                        placeholder="Введите email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                </Col>

                <Col>
                    <Form.Label>
                        Дата (по умолчанию сегодняшняя)
                    </Form.Label>
                    <Form.Control
                        type="date"
                        value={selectedDate}
                        onChange={(e) => setSelectedDate(e.target.value)}
                    />
                </Col>
            </Form.Group>

            <Form.Group as={Row}>
                <Button variant="primary" onClick={handleSearch}>
                    Поиск
                </Button>
            </Form.Group>
        </Form>
    );
};

export default SearchForm;