import styles from './layout.module.css';
import {ToastContainer, toast} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import TelegramIcon from '../../images/telegram.png';

export const launchError = (error) => {
    if (error?.response?.data?.message) {
        toast.error(error.response.data.message);
    }
    if (error?.response?.data) {
        toast.error(error.response.data);
    } else
        toast.error('Unknown Error');
}

export const launchSuccess = (message) => {
    toast.success(message.data);
}

const Layout = ({children}) => {
    return (
        <>
            <ToastContainer/>
            <div className={styles.telegram}>
                <a href="https://t.me/alexeykhr" target="_blank" rel="noreferrer">
                    <img
                        src={TelegramIcon}
                        alt="Telegram"/>
                </a>
            </div>
            {children}
        </>
    )
}

export default Layout;