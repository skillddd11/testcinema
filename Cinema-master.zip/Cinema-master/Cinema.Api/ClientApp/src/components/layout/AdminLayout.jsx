import {Nav, Navbar} from "react-bootstrap";
import React from "react";
import {useNavigate} from "react-router-dom";

const AdminLayout = ({children}) => {
    const navigate = useNavigate();

    return (
        <>
            <div className="d-flex flex-column" style={{minHeight: '100vh'}}>
                <Navbar bg="dark" variant="dark" className={'p-3'}>
                    <Navbar.Brand onClick={() => navigate('/admin')}>
                        Адмінка
                    </Navbar.Brand>
                    <Nav className="mr-auto">
                        <Nav.Link onClick={() => navigate('/admin/movies')}>Фільми</Nav.Link>
                        <Nav.Link onClick={() => navigate('/admin/halls')}>Зали</Nav.Link>
                        <Nav.Link onClick={() => navigate('/admin/prices')}>Ціни</Nav.Link>
                        <Nav.Link onClick={() => navigate('/admin/reservations')}>Брони</Nav.Link>
                    </Nav>
                </Navbar>
                {children}
                <footer className="bg-dark text-white text-center py-3 mt-auto">
                    <p>&copy; 2023 Movie Admin Panel</p>
                </footer>
            </div>
        </>
    )
}

export default AdminLayout;