import styles from "./footer.module.css";
import {cities} from "../../api/data";
import {useNavigate} from "react-router-dom";

const Footer = () => {
    const name = localStorage.getItem('name');
    const navigate = useNavigate();

    return (
        <footer className={styles.footer}>
            <div className={styles.divFooterContainer}>
                <div className={styles.list}>
                    <div className={styles.itemMargin}>
                        <div className={styles.link5} onClick={() => navigate('/about')}>
                            О кинотеатре
                        </div>
                    </div>
                    <div className={styles.itemMargin}>
                        <div className={styles.link5} onClick={() => navigate('/about/services')}>
                            Услуги
                        </div>
                    </div>
                    <div className={styles.itemMargin}>
                        <div className={styles.link5} onClick={() => navigate('/prices')}>
                            Цены
                        </div>
                    </div>
                    <div className={styles.itemMargin}>
                        <div className={styles.link5} onClick={() => navigate('/about/restaurant')}>
                            Ресторан
                        </div>
                    </div>
                    <div className={styles.itemMargin}>
                        <div className={styles.link5} onClick={() => navigate('/about/gallery')}>
                            Галерея
                        </div>
                    </div>
                    <div className={styles.itemMargin}>
                        <div className={styles.link5} onClick={() => navigate('/about/contacts')}>
                            Контакты
                        </div>
                    </div>
                </div>
                <div className={styles.divFooterInfo}>
                    <div className={styles.divFooterItem}>
                        <div className={styles.divFooterDesc}>
                            <p className={styles.textWrapper7}>
                                Часы работы: с 12:00-03:00; в выходные дни с 11:00-03:00
                            </p>
                        </div>
                        <div className={styles.divFooterDesc}>
                            <div className={styles.textWrapper7}>
                                © 2023 Кинотеатр «Москва».
                            </div>
                        </div>
                    </div>
                    <div className={styles.divFooterItem}>
                        <div className={styles.textWrapper8}>
                            sales@cinema.moscow
                        </div>
                    </div>
                    <div className={styles.divFooterItem} style={{paddingRight: 150}}>
                        <div className={styles.divFooterDesc}>
                            <div className={styles.textWrapper7}>
                                {name || cities.moskva}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    )
}

export default Footer;