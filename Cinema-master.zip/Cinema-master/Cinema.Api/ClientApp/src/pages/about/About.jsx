import styles from './about.module.css';
import Header from "../../components/header/Header";
import Footer from "../../components/footer/Footer";
import about from '../../images/about.png';
import image1 from '../../images/Rest1.png';
import image2 from '../../images/Rest2.png';
import image3 from '../../images/Rest3.jpg';
import image4 from '../../images/Rest4.jpg';
import image5 from '../../images/Rest5.jpg';
import hall2 from '../../images/hall2.png';
import hall4 from '../../images/hall4.png';
import hall7 from '../../images/hall7.png';
import {useEffect, useState} from "react";
import Carousel from 'react-bootstrap/Carousel';
import {useParams} from "react-router-dom";
import services1 from "../../images/services1.png";
import services2 from "../../images/services2.png";
import services3 from "../../images/services3.png";
import services4 from "../../images/services4.png";
import services5 from "../../images/services5.png";
import services6 from "../../images/services6.png";
import services7 from "../../images/services7.png";
import services8 from "../../images/services8.png";
import services9 from "../../images/services9.png";

const About = () => {
    const [scroll, setScroll] = useState(40);
    const [active, setActive] = useState(0);
    const param = useParams().param;

    useEffect(() => {
        switch (param) {
            case 'services':
                scrollTo(1);
                break;
            case 'restaurant':
                scrollTo(2);
                break;
            case 'gallery':
                scrollTo(3);
                break;
            case 'contacts':
                scrollTo(4);
                break;
            default:
                scrollTo(0);
                break;
        }
    }, [param]);

    window.addEventListener('scroll', () => {
            const scrollPercentage = (document.documentElement.scrollTop / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
            const translatePercentage = 40 + (scrollPercentage * 1.5);

            if (translatePercentage > 80)
                setScroll(80);
            else if (translatePercentage < 40)
                setScroll(40);
            else
                setScroll(translatePercentage);

            document.querySelectorAll('section').forEach((section, index) => {
                if (section.getBoundingClientRect().top < window.innerHeight / 2 && section.getBoundingClientRect().bottom > window.innerHeight / 2) {
                    setActive(index);
                }
            });
        }
    )

    const scrollTo = (index) => {
        const section = document.querySelectorAll('section')[index];
        if (section.previousElementSibling)
            section.previousElementSibling.scrollIntoView({behavior: "smooth", block: "start"});
        else
            section.scrollIntoView({behavior: "smooth"});
    }

    return (
        <>
            <Header navigation change={active} onClick={scrollTo}/>
            <div className={styles.wrap}>
                <section>
                    <div>
                        <div className={styles.overlapGroup}>
                            <div className={styles.divWrapper}>
                                <div className={styles.textWrapper}>
                                    «Звезда» —
                                    это кинотеатр для тех,
                                    кто ценит качество
                                    во всех проявлениях
                                </div>
                            </div>
                            <div className={styles.div}
                                 style={{
                                     backgroundImage: `url(${about})`,
                                     transform: ` translate3d(0px, ${scroll}%, 0px)`
                                 }}>
                            </div>
                        </div>
                    </div>
                </section>
                <div className={styles.separate}>услуги</div>
                <section>
                    <div className={styles.services}>
                        <div className={styles.services_container}>
                            <div className={styles.services_title}>
                                «Звезда» — кинотеатр уникальных возможностей!
                            </div>
                            <div className={styles.services_row}>
                                {
                                    services.map((item, index) => (
                                        <div className={styles.services_col} key={index}>
                                            <div>
                                                <img src={item.img} alt="" className={styles.service_img}/>
                                            </div>
                                            <div className={styles.service_text}>
                                                {item.text}
                                            </div>
                                        </div>
                                    ))
                                }
                            </div>
                        </div>
                    </div>
                </section>
                <div className={styles.separate}>Ресторан</div>
                <section className={styles.black}>
                    <div className={styles.rest}>
                        <Carousel>
                            <Carousel.Item>
                                <img
                                    src={image1}
                                    alt={""} className={styles.carousel}/>
                            </Carousel.Item>
                            <Carousel.Item>
                                <img
                                    src={image2}
                                    alt={""} className={styles.carousel}/>
                            </Carousel.Item>
                            <Carousel.Item>
                                <img
                                    src={image3}
                                    alt={""} className={styles.carousel}/>
                            </Carousel.Item>
                            <Carousel.Item>
                                <img
                                    src={image4}
                                    alt={""} className={styles.carousel}/>
                            </Carousel.Item>
                            <Carousel.Item>
                                <img
                                    src={image5}
                                    alt={""} className={styles.carousel}/>
                            </Carousel.Item>
                        </Carousel>
                        <div className={styles.description}>
                            <p>С момента открытия ресторан «Звезда» стал рестораном традиций — здесь принято вкусно и
                                по‑итальянски, обедать, ужинать, и начинать выходные с ланча перед киносеансом.</p>
                            <p>В основе концепции меню ресторана лежит средиземноморская кухня Италии. Блюда исполнены в
                                соответствии с классическими рецептами. Отдельно стоит выделить блюда, которые удобно
                                есть во время просмотра фильмов: пиццы, бургеры и сэндвичи.</p>
                            <p>Также в ресторан способен удивить опытных знатоков барной и кальянной культуры. Симбиоз
                                большого выбора алкогольных напитков и lounge атмосферы – дает возможность заведению
                                быть настоящим «бриллиантом» хорошего отдыха. Коктейльное меню состоит из классических
                                миксов, авторских коктейлей, hand-made и китайских чаев.</p>
                            <p>Часы работы ресторана: с 12:00-00:00; в выходные дни с 11:00-00:00.</p>
                        </div>
                    </div>
                </section>
                <div className={styles.separate}>Галерея</div>
                <section className={styles.black}>
                    <div className={styles.gallery}>
                        <Carousel>
                            <Carousel.Item>
                                <img
                                    src={hall2}
                                    alt={""} className={styles.carousel}/>
                                <Carousel.Caption className={styles.caption}>
                                    Зал 2
                                </Carousel.Caption>
                            </Carousel.Item>
                            <Carousel.Item>
                                <img
                                    src={hall4}
                                    alt={""} className={styles.carousel}/>
                                <Carousel.Caption className={styles.caption}>
                                    Зал 4
                                </Carousel.Caption>
                            </Carousel.Item>
                            <Carousel.Item>
                                <img
                                    src={hall7}
                                    alt={""} className={styles.carousel}/>
                                <Carousel.Caption className={styles.caption}>
                                    Зал 7
                                </Carousel.Caption>
                            </Carousel.Item>
                        </Carousel>
                    </div>
                </section>
                <div className={styles.separate}>Контакти</div>
                <section>
                    <div className={styles.contacts_content}>
                        <div className={styles.contacts}>
                            <div className={styles.contacts_container}>
                                <div className={styles.contacts_title}>
                                    Сотрудники киноклуба «Звезда» будут рады ответить на все интересующие вопросы,
                                    связанные с работой кинотеатра и ресторанов
                                </div>
                                <div className={styles.contacts_list}>
                                    {
                                        contacts.map((item, index) =>
                                            <div className={styles.contacts_item} key={index}>
                                                {item.title &&
                                                    <div className={styles.contacts_subtitle}>{item.title}</div>}
                                                {item.phone &&
                                                    <div className={styles.contacts_phone}>{item.phone}</div>}
                                                {item.email &&
                                                    <div className={styles.contacts_email}>{item.email}</div>}
                                            </div>
                                        )
                                    }
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <Footer/>
        </>
    )
}

const contacts = [
    {title: 'КИНОТЕАТР «ЗВЕЗДА»', phone: 'https://t.me/'},
    {title: 'РЕСТОРАН «ЗВЕЗДА»', phone: 'https://t.me/'},
    {},
    {title: 'PR И ВЗАИМОДЕЙСТВИE СО СМИ', email: 'some@email.com'},
    {title: 'РЕКЛАМА В КИНОТЕАТРЕ', email: 'some@email.com'},
    {title: 'ОРГАНИЗАЦИЯ МЕРОПРИЯТИЙ', email: 'some@email.com'},
    {title: 'ВОПРОСЫ ТРУДОУСТРОЙСТВА', email: 'some@email.com'},
]

const services = [
    {
        img: services1,
        text: 'Возможность арендовать как уютный зал для 2 персон, так и большой зал, для веселой компании'
    },
    {
        img: services2,
        text: 'Возможность насладиться средиземноморской и современной американской кухней ресторана “Звезда”'
    },
    {
        img: services3,
        text: 'ППерсональный консьерж, который возьмет на себя организацию досуга на территории кинокомплекса'
    },
    {
        img: services4,
        text: 'Возможность смотреть практически любые фильмы на языке оригинала, наслаждаясь оригинальными голосами актеров'
    },
    {
        img: services5,
        text: 'Доступ к кинокартинам, вышедшим из широкого проката, популярным сериалам и театральным постановкам'
    },
    {
        img: services6,
        text: 'Возможность посещать светские премьеры и закрытые показы самых популярных в мире фильмов'
    },
    {
        img: services7,
        text: 'Профессиональная караоке-система станет прекрасным дополнением к вашему вечеру в компании друзей'
    },
    {
        img: services8,
        text: 'Возможность осуществить мечту любого, кто неравнодушен к компьютерным играм и получить незабываемые впечатления от игры на приставке на большем экране со звуком, которому позавидует любой геймер планеты'
    },
    {
        img: services9,
        text: 'Возможность поболеть за любимого игрока или команду в ходе просмотра любой спортивной трансляции на ваш выбор'
    }
]

export default About;