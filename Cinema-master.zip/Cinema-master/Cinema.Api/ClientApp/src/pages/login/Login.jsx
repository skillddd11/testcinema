import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './login.css';

const Login = () => {
    return (
        <div className="container-fluid">
            <div className="row justify-content-center align-items-center full-height">
                <div className="col-md-4">
                    <h2 className="text-center mb-4">Login Form</h2>
                    <div className="card">
                        <div className="card-body">
                            <form>
                                <div className="mb-3">
                                    <label htmlFor="username" className="form-label">
                                        Username
                                    </label>
                                    <input type="text" className="form-control" id="username"/>
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="password" className="form-label">
                                        Password
                                    </label>
                                    <input type="password" className="form-control" id="password"/>
                                </div>
                                <div className="mb-3">
                                    <button type="submit" className="btn btn-primary btn-block">
                                        Login
                                    </button>
                                </div>
                                <p className="text-center">Forgot password?</p>
                            </form>
                        </div>
                    </div>
                    <p className="text-center mt-3">Don't have an account? Sign up here.</p>
                </div>
            </div>
        </div>
    );
};

export default Login;
