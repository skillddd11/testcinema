import styles from './home.module.css';
import Header from "../../components/header/Header";
import Footer from "../../components/footer/Footer";
import {useEffect, useState} from "react";
import MovieCard from "../../components/movie-card/MovieCard";
import Carousel from "react-bootstrap/Carousel";
import {apiEndpoint} from "../../api";
import {useNavigate, useParams} from "react-router-dom";
import {cities} from "../../api/data";

const AvatarWrapper = ({image, name}) => {
    return (
        <div className={styles.wrap}>
            <div className={styles.divHomeEventPhoto}>
                <div className={styles.div}>
                    <div className={styles.smallSquareJpg} style={{backgroundImage: `url(${image})`}}/>
                </div>
            </div>
            <div className={styles.divWrapper2}>
                {name}
            </div>
        </div>
    )
}

const Home = () => {
    const [films, setFilms] = useState([]);
    const navigate = useNavigate();
    const {id} = useParams();

    useEffect(() => {
        apiEndpoint('main/page').fetch()
            .then(res => setFilms(res.data))
            .catch(err => console.log(err));
    }, []);

    useEffect(() => {
        if (id) {
            localStorage.setItem('name', cities[id]);
            navigate('/');
        }
    }, [id, navigate]);

    const getDateString = (start, end) => {
        const startDate = new Date(start);
        const endDate = new Date(end);

        const startString = startDate.getDay() + ' ' + startDate.toLocaleString('ru', {month: 'long'}) + ' ' + startDate.getFullYear();
        const endString = endDate.getDay() + ' ' + endDate.toLocaleString('ru', {month: 'long'});

        return `${startString} - ${endString}`;
    }

    return (
        <>
            <Header/>
            <div className={styles.main}>
                <div className={styles.background}>
                    {
                        films.filter(f => f.avatar).length > 0 &&
                        <div className={styles.avatars}>
                            {
                                films.filter(f => f.avatar).map((item, index) => {
                                        if (index < 3)
                                            return <AvatarWrapper image={item['imageUrl']} name={item.title}
                                                                  key={index + 'avatar'}/>
                                        else return null;
                                    }
                                )
                            }
                        </div>
                    }
                    {
                        films.filter(f => f.premiere).length > 0 &&
                        <div>
                            <Carousel>
                                {
                                    films.filter(f => f.premiere).map((item) =>
                                        <Carousel.Item key={'carousel' + item.title}>
                                            <img src={item['imageUrl']}
                                                 alt={""} className={styles.carrouselItem}/>
                                            <Carousel.Caption>
                                                <div className={styles.itemTitle}>Кинопремьеры</div>
                                                {item.title && <div className={styles.itemText}>{item.title}</div>}
                                            </Carousel.Caption>
                                        </Carousel.Item>
                                    )
                                }
                            </Carousel>
                        </div>
                    }
                    <div className={styles.films}>
                        {
                            films.map((item) => <MovieCard name={item.title} link={item['imageUrl']} key={item.title}
                                                           date={getDateString(item['startDate'], item['endDate'])}
                                                           big={item['bigImage']}/>)
                        }
                    </div>
                </div>
            </div>
            <Footer/>
        </>
    );
}

export default Home;
