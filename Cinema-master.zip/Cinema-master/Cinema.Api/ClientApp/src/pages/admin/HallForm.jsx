import React, {useEffect, useState} from 'react';
import {Form, Button, Col, Container, Row} from 'react-bootstrap';
import {useNavigate, useParams} from "react-router-dom";
import styles from "./styles.module.css";
import {useDropzone} from "react-dropzone";
import {apiEndpoint} from "../../api";

const HallForm = () => {
    const hallId = useParams().id;

    const [hall, setHall] = useState(null);
    const [selectedFile, setSelectedFile] = useState(null);
    const [fileUrl, setFileUrl] = useState(null);
    const [prices, setPrices] = useState([]);

    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        number: hall?.number || '',
        capacity: hall?.capacity || '',
        priceId: hall?.priceId || '',
    });

    useEffect(() => {
        if (hallId) {
            apiEndpoint('hall').fetchById(hallId)
                .then(res => {
                    setHall(res.data);
                    setFileUrl(res.data.url);
                })
                .catch(err => console.log(err));
        }
        apiEndpoint('price').fetch()
            .then(res => setPrices(res.data.map(p => ({value: p.id, label: p.name}))))
            .catch(err => console.log(err));
    }, [hallId]);

    useEffect(() => {
        setFormData({
            number: hall?.number || '',
            capacity: hall?.capacity || '',
            priceId: hall?.priceId || '',
        });
    }, [hall]);

    const handleChange = (e) => {
        const {name, value} = e.target;
        setFormData({...formData, [name]: value});
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        const hallDto = new FormData();

        for (let dataKey in formData) {
            hallDto.append(dataKey, formData[dataKey]);
        }

        if (selectedFile)
            hallDto.append('Image', selectedFile);

        if (hallId) {
            apiEndpoint('hall/' + hallId, true).put(hallDto)
                .then(() => navigate('/admin/halls'))
                .catch(err => console.log(err))
        } else {
            apiEndpoint('hall', true).post(hallDto)
                .then(() => navigate('/admin/halls'))
                .catch(err => console.log(err))
        }
    };

    const onDrop = (acceptedFiles) => {
        const file = acceptedFiles[0];

        if (file) {
            setSelectedFile(file);
        } else {
            setSelectedFile(null);
        }
    };

    const {getRootProps, getInputProps, isDragActive} = useDropzone({onDrop});

    return (
        <Container className="mt-5 mb-5">
            <Row className="justify-content-md-center">
                <Col md={8}>
                    <Button variant="outline-primary" onClick={() => navigate('/admin/halls')}>
                        Назад
                    </Button>
                    <Form className="mt-3 d-flex gap-3 flex-column" onSubmit={handleSubmit}>
                        <Form.Group controlId="formHallName">
                            <Form.Label>Номер залу</Form.Label>
                            <Form.Control
                                type="number"
                                placeholder="Введіть номер залу"
                                name="number"
                                value={formData.number}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>

                        <Form.Group controlId="formCapacity">
                            <Form.Label>Кількість місць</Form.Label>
                            <Form.Control
                                type="number"
                                placeholder="Введіть кількість місць"
                                name="capacity"
                                value={formData.capacity}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>

                        <Form.Group controlId="exampleForm.SelectCustom">
                            <Form.Label>Виберіть ціну на зал</Form.Label>
                            <Form.Control as="select" custom onChange={handleChange} value={formData.priceId} name={'priceId'}>
                                <option value="" disabled>
                                    Виберіть ціну...
                                </option>
                                {prices.map((option) => (
                                    <option key={option.value} value={option.value}>
                                        {option.label}
                                    </option>
                                ))}
                            </Form.Control>
                        </Form.Group>

                        <Form.Group controlId="formFile">
                            <div {...getRootProps()}
                                 className={`${styles.dropzone} ${isDragActive ? styles.active : ''}`}>
                                <input {...getInputProps()} accept=".jpg, .jpeg, .png, .gif"/>
                                <p className={'m-0'}>
                                    Перетягніть сюди файл або натисніть для вибору файлу
                                </p>
                            </div>
                        </Form.Group>

                        {
                            (selectedFile || fileUrl) && (
                                <div>
                                    <img
                                        src={selectedFile ? URL.createObjectURL(selectedFile) : fileUrl}
                                        className="img-thumbnail w-100"
                                        alt="File Preview"
                                    />
                                </div>
                            )
                        }

                        <Button variant="primary" type="submit">
                            Зберегти
                        </Button>
                    </Form>
                </Col>
            </Row>
        </Container>
    );
};

export default HallForm;
