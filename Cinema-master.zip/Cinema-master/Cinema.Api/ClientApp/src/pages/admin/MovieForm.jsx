import React, {useEffect, useState} from 'react';
import {Form, Button, Col, Container, Row} from 'react-bootstrap';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import {useNavigate, useParams} from "react-router-dom";
import {apiEndpoint} from "../../api";
import {useDropzone} from 'react-dropzone';
import styles from './styles.module.css';

const MovieForm = () => {
    const movieId = useParams().id;
    const [movie, setMovie] = useState(null);
    const [selectedFile, setSelectedFile] = useState(null);
    const [fileUrl, setFileUrl] = useState(null);

    const navigate = useNavigate();

    useEffect(() => {
        if (movieId) {
            apiEndpoint('movie').fetchById(movieId)
                .then(res => {
                    setMovie(res.data);
                    setFileUrl(res.data['imageUrl']);
                })
                .catch(err => console.log(err));
        }
    }, [movieId]);

    const getMovieObject = (movie) => {
        return {
            title: movie?.title || '',
            description: movie?.description || '',
            premiere: movie?.premiere || false,
            bigImage: movie?.bigImage || false,
            startDate: movie?.startDate ? new Date(movie.startDate) : new Date(),
            endDate: movie?.endDate ? new Date(movie.endDate) : new Date(),
            avatar: movie?.avatar || false,
            country: movie?.country || '',
            genre: movie?.genre || '',
            director: movie?.director || '',
            actors: movie?.actors || '',
            duration: movie?.duration || '',
            scenarist: movie?.scenarist || '',
            ageFrom: movie?.ageFrom || '',
        }
    }

    const [formData, setFormData] = useState(getMovieObject(movie));

    useEffect(() => {
        setFormData(getMovieObject(movie));
    }, [movie]);

    const handleChange = (e) => {
        const {name, value} = e.target;
        setFormData({...formData, [name]: value});
    };

    const handleCheck = (e) => {
        const {name, checked} = e.target;
        setFormData({...formData, [name]: checked});
    }

    const onDrop = (acceptedFiles) => {
        const file = acceptedFiles[0];

        if (file) {
            setSelectedFile(file);
        } else {
            setSelectedFile(null);
        }
    };

    const {getRootProps, getInputProps, isDragActive} = useDropzone({onDrop});

    const handleStartDateChange = (date) => {
        setFormData({...formData, startDate: date});
    };

    const handleEndDateChange = (date) => {
        setFormData({...formData, endDate: date});
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        const movieDto = new FormData();

        for (let dataKey in formData) {
            if (dataKey.includes('Date'))
                movieDto.append(dataKey, formData[dataKey].toISOString());
            else
                movieDto.append(dataKey, formData[dataKey]);
        }

        if (selectedFile)
            movieDto.append('Image', selectedFile);

        if (movieId) {
            apiEndpoint('movie/' + movieId, true).put(movieDto)
                .then(() => navigate('/admin'))
                .catch(err => console.log(err))
        } else {
            apiEndpoint('movie', true).post(movieDto)
                .then(() => navigate('/admin'))
                .catch(err => console.log(err))
        }
    };

    return (
        <Container className="mt-5 mb-5">
            <Row className="justify-content-md-center">
                <Col md={8}>
                    <Button variant="outline-primary" onClick={() => navigate('/admin')}>
                        Назад
                    </Button>

                    <Form className="mt-3 d-flex gap-3 flex-column" onSubmit={handleSubmit}>
                        <Form.Group controlId="formTitle">
                            <Form.Label>Назва</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Введіть назву"
                                name="title"
                                value={formData.title}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>

                        <Form.Group controlId="formDescription">
                            <Form.Label>Опис</Form.Label>
                            <Form.Control
                                as="textarea"
                                type="text"
                                placeholder="Введіть опис"
                                name="description"
                                value={formData.description}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>

                        <Form.Group controlId="formCountry">
                            <Form.Label>Страна</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Введите страну"
                                name="country"
                                value={formData.country}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>

                        <Form.Group controlId="formGenre">
                            <Form.Label>Жанр</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Введіть жанр"
                                name="genre"
                                value={formData.genre}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>

                        <Form.Group controlId="formDirector">
                            <Form.Label>Режисеры</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Введите режисеров"
                                name="director"
                                value={formData.director}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>

                        <Form.Group controlId="formActors">
                            <Form.Label>Актеры</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Введите актеров"
                                name="actors"
                                value={formData.actors}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>

                        <Form.Group controlId="formDuration">
                            <Form.Label>Время показа</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="1 час 30 минут"
                                name="duration"
                                value={formData.duration}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>

                        <Form.Group controlId="formScenarist">
                            <Form.Label>Сценаристы</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Введите сценаристов"
                                name="scenarist"
                                value={formData.scenarist}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>

                        <Form.Group controlId="formAgeFrom">
                            <Form.Label>Введите ограничение по возрасту</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="12+"
                                name="ageFrom"
                                value={formData.ageFrom}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>

                        <Form.Group controlId="formFile">
                            <div {...getRootProps()}
                                 className={`${styles.dropzone} ${isDragActive ? styles.active : ''}`}>
                                <input {...getInputProps()} accept=".jpg, .jpeg, .png, .gif"/>
                                <p className={'m-0'}>
                                    Перетягніть сюди файл або натисніть для вибору файлу
                                </p>
                            </div>
                        </Form.Group>

                        {
                            (selectedFile || fileUrl) && (
                                <div>
                                    <img
                                        src={selectedFile ? URL.createObjectURL(selectedFile) : fileUrl}
                                        className="img-thumbnail w-100"
                                        alt="File Preview"
                                    />
                                </div>
                            )
                        }

                        <Row>
                            <Col md={6}>
                                <Form.Group controlId="formStartDate" className={'d-flex gap-3 align-items-center'}>
                                    <Form.Label className={'m-0'}>Початок показу</Form.Label>
                                    <DatePicker
                                        selected={formData.startDate}
                                        onChange={handleStartDateChange}
                                        dateFormat="MMMM d, yyyy"
                                        className="form-control"
                                    />
                                </Form.Group>
                            </Col>
                            <Col md={6} className="d-flex justify-content-end">
                                <Form.Group controlId="formEndDate" className={'d-flex gap-3 align-items-center'}>
                                    <DatePicker
                                        selected={formData.endDate}
                                        onChange={handleEndDateChange}
                                        dateFormat="MMMM d, yyyy"
                                        className="form-control"
                                    />
                                    <Form.Label className={'m-0'}>Кінець показу</Form.Label>
                                </Form.Group>
                            </Col>
                        </Row>

                        <Row>
                            <Col md={4}>
                                <Form.Group controlId="formPremiere">
                                    <Form.Check
                                        checked={formData.premiere}
                                        onChange={handleCheck}
                                        name={'premiere'}
                                        label={"Прем'єра"}
                                    />
                                </Form.Group>
                            </Col>
                            <Col md={4} className="d-flex justify-content-center">
                                <Form.Group controlId="formBigImage">
                                    <Form.Check
                                        checked={formData.bigImage}
                                        onChange={handleCheck}
                                        name={'bigImage'}
                                        label={'Велике зображення'}
                                    />
                                </Form.Group>
                            </Col>
                            <Col md={4} className="d-flex justify-content-end">
                                <Form.Group controlId="formAvatar">
                                    <Form.Check
                                        checked={formData.avatar}
                                        onChange={handleCheck}
                                        name={'avatar'}
                                        label={'Аватар'}
                                    />
                                </Form.Group>
                            </Col>
                        </Row>

                        <Button variant="primary" type="submit">
                            Зберегти
                        </Button>
                    </Form>
                </Col>
            </Row>
        </Container>
    );
};

export default MovieForm;
