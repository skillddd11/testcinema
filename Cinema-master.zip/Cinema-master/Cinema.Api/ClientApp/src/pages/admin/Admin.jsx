import React, {useEffect, useState} from 'react';
import {Card, Button, ButtonGroup} from 'react-bootstrap';
import {useNavigate, useParams} from "react-router-dom";
import {apiEndpoint} from "../../api";
import SearchForm from "../../components/searchForm/SearchForm";

const AdminPanel = () => {
    const page = useParams().page;

    const switchPage = (page) => {
        switch (page) {
            case undefined:
            case 'movies':
                return <Movies/>
            case 'halls':
                return <Halls/>
            case 'prices':
                return <Prices/>
            case 'reservations':
                return <Reservations/>
            default:
                return <h1>No such page</h1>
        }
    }

    return (
        <>
            {switchPage(page)}
        </>
    );
};

const Prices = () => {
    const navigate = useNavigate();
    const [prices, setPrices] = useState([]);

    useEffect(() => {
        apiEndpoint('price').fetch()
            .then(res => setPrices(res.data))
            .catch(err => console.log(err));
    }, []);

    const handleDelete = (id) => {
        apiEndpoint('price').deleteById(id)
            .then(res => setPrices(prices.filter(movie => movie.id !== id)))
            .catch(err => console.log(err));
    }

    return (
        <>
            <div className="container mt-4">
                <Button variant="outline-primary" onClick={() => navigate('/admin/price')}>
                    Додати Ціну
                </Button>
                <div className="row mt-3">
                    {
                        prices.map((price) => (
                            <div key={price.id} className="col-md-4 mb-4">
                                <Card>
                                    <Card.Body>
                                        <Card.Title>{price.name}</Card.Title>
                                        <ButtonGroup className="d-flex justify-content-between mt-3">
                                            <Button
                                                variant="info"
                                                onClick={() => navigate('/admin/price/' + price.id)}
                                            >
                                                Редагувати
                                            </Button>
                                            <Button variant="danger" onClick={() => handleDelete(price.id)}>
                                                Видалити
                                            </Button>
                                        </ButtonGroup>
                                    </Card.Body>
                                </Card>
                            </div>
                        ))
                    }
                </div>
            </div>
        </>
    )
}

const Movies = () => {
    const navigate = useNavigate();
    const [movies, setMovies] = useState([]);

    useEffect(() => {
        apiEndpoint('movie').fetch()
            .then(res => setMovies(res.data))
            .catch(err => console.log(err));
    }, []);

    const handleDelete = (id) => {
        apiEndpoint('movie').deleteById(id)
            .then(res => setMovies(movies.filter(movie => movie.id !== id)))
            .catch(err => console.log(err));
    }

    return (
        <>
            <div className="container mt-4">
                <Button variant="outline-primary" onClick={() => navigate('/admin/movie')}>
                    Додати Фільм
                </Button>
                <div className="row mt-3">
                    {
                        movies.map((movie) => (
                            <div key={movie.id} className="col-md-4 mb-4">
                                <Card>
                                    <Card.Img variant="top" src={movie['imageUrl']}/>
                                    <Card.Body>
                                        <Card.Title>{movie.title}</Card.Title>
                                        <Card.Text
                                            style={{maxHeight: 200, overflow: 'scroll'}}>{movie.description}</Card.Text>
                                        <ButtonGroup className="d-flex justify-content-between mt-3">
                                            <Button
                                                variant="info"
                                                onClick={() => navigate('/admin/movie/' + movie.id)}
                                            >
                                                Редагувати
                                            </Button>
                                            <Button variant="danger" onClick={() => handleDelete(movie.id)}>
                                                Видалити
                                            </Button>
                                        </ButtonGroup>
                                    </Card.Body>
                                </Card>
                            </div>
                        ))
                    }
                </div>
            </div>
        </>
    )
}

const Halls = () => {
    const navigate = useNavigate();
    const [halls, setHalls] = useState([]);

    useEffect(() => {
        apiEndpoint('hall').fetch()
            .then(res => setHalls(res.data))
            .catch(err => console.log(err));
    }, []);

    const handleDelete = (id) => {
        apiEndpoint('hall').deleteById(id)
            .then(res => setHalls(halls.filter(movie => movie.id !== id)))
            .catch(err => console.log(err));
    }

    return (
        <>
            <div className="container mt-4">
                <Button variant="outline-primary" onClick={() => navigate('/admin/hall')}>
                    Додати Зал
                </Button>
                <div className="row mt-3">
                    {
                        halls.map((hall) => (
                            <div key={hall.id} className="col-md-4 mb-4">
                                <Card>
                                    <Card.Img variant="top" src={hall.url}/>
                                    <Card.Body>
                                        <Card.Title>Зал № {hall.number}</Card.Title>
                                        <Card.Text>Кількість місць: {hall.capacity}</Card.Text>
                                        <ButtonGroup className="d-flex justify-content-between mt-3">
                                            <Button
                                                variant="info"
                                                onClick={() => navigate('/admin/hall/' + hall.id)}
                                            >
                                                Редагувати
                                            </Button>
                                            <Button variant="danger" onClick={() => handleDelete(hall.id)}>
                                                Видалити
                                            </Button>
                                        </ButtonGroup>
                                    </Card.Body>
                                </Card>
                            </div>
                        ))
                    }
                </div>
            </div>
        </>
    )
}

const Reservations = () => {
    const [reservations, setReservations] = useState([]);

    useEffect(() => {
        apiEndpoint('main/reservations').post({})
            .then(res => setReservations(res.data))
            .catch(err => console.log(err));
    }, []);

    const handleSearch = (searchParams) => {
        apiEndpoint('main/reservations').post(searchParams)
            .then(res => setReservations(res.data))
            .catch(err => console.log(err));
    };

    const mapTime = (hour) => {
        if (hour < 10)
            return `0${hour}:00`;
        return `${hour}:00`;
    }

    return (
        <>
            <div className="container mt-4">
                <SearchForm onSearch={handleSearch}/>
                <div className="row mt-3">
                    {
                        reservations.map((reservation) => (
                            <div key={reservation.id} className="col-md-4 mb-4">
                                <Card>
                                    <Card.Body>
                                        <Card.Title>
                                            Бронь {new Date(reservation['reservationDate']).toLocaleDateString()}
                                            {' '}<b>{mapTime(reservation.hour)} - {mapTime(reservation.hour + reservation['reservationHours'])}</b>
                                        </Card.Title>
                                        <Card.Text><b>Кількість місць</b>: {reservation['hall'].capacity}</Card.Text>
                                        <Card.Text><b>Фильм</b>: {reservation['movie'].title}</Card.Text>
                                        <Card.Text><b>Бар</b>: {reservation.bar ? 'Да' : 'Нет'} | <b>Цена</b>: {reservation.price} руб.</Card.Text>
                                        <Card.Text><b>Имя</b>: {reservation.name} | <b>Email</b>: {reservation.email}
                                        </Card.Text>
                                    </Card.Body>
                                </Card>
                            </div>
                        ))
                    }
                </div>
            </div>
        </>
    )
}

export default AdminPanel;