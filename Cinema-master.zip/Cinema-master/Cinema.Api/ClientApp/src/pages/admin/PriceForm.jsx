import {useNavigate, useParams} from "react-router-dom";
import React, {useEffect, useState} from "react";
import {apiEndpoint} from "../../api";
import {Button, Col, Container, Form, Row} from "react-bootstrap";

const PriceForm = () => {
    const priceId = useParams().id;
    const [price, setPrice] = useState(null);

    const navigate = useNavigate();

    useEffect(() => {
        if (priceId) {
            apiEndpoint('price').fetchById(priceId)
                .then(res => setPrice(res.data))
                .catch(err => console.log(err));
        }
    }, [priceId]);

    const [formData, setFormData] = useState({
        name: price?.name || '',
        pricePer2Hours: price?.pricePer2Hours || 0,
        pricePer4Hours: price?.pricePer4Hours || 0,
        pricePer6Hours: price?.pricePer6Hours || 0,
        pricePer2HoursEvening: price?.pricePer2HoursEvening || 0,
        pricePer4HoursEvening: price?.pricePer4HoursEvening || 0,
        pricePer6HoursEvening: price?.pricePer6HoursEvening || 0,
    });

    useEffect(() => {
        setFormData({
            name: price?.name || '',
            pricePer2Hours: price?.pricePer2Hours || 0,
            pricePer4Hours: price?.pricePer4Hours || 0,
            pricePer6Hours: price?.pricePer6Hours || 0,
            pricePer2HoursEvening: price?.pricePer2HoursEvening || 0,
            pricePer4HoursEvening: price?.pricePer4HoursEvening || 0,
            pricePer6HoursEvening: price?.pricePer6HoursEvening || 0,
        });
    }, [price]);

    const handleChange = (e) => {
        const {name, value} = e.target;
        setFormData({...formData, [name]: value});
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        if (priceId) {
            apiEndpoint('price').put({id: priceId, ...formData})
                .then(() => navigate('/admin'))
                .catch(err => console.log(err))
        } else {
            apiEndpoint('price').post(formData)
                .then(() => navigate('/admin'))
                .catch(err => console.log(err))
        }
    };

    return (
        <Container className="mt-5 mb-5">
            <Row className="justify-content-md-center">
                <Col md={8}>
                    <Button variant="outline-primary" onClick={() => navigate('/admin')}>
                        Назад
                    </Button>
                    <Form className="mt-3 d-flex gap-3 flex-column" onSubmit={handleSubmit}>
                        <Form.Group controlId="formTitle">
                            <Form.Label>Назва</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Введіть назву"
                                name="name"
                                value={formData.name}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="formTitle">
                            <Form.Label>Ціна за 2 години</Form.Label>
                            <Form.Control
                                type="number"
                                placeholder="Введіть ціну за 2 години"
                                name="pricePer2Hours"
                                value={formData.pricePer2Hours}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="formTitle">
                            <Form.Label>Ціна за 4 години</Form.Label>
                            <Form.Control
                                type="number"
                                placeholder="Введіть ціну за 4 години"
                                name="pricePer4Hours"
                                value={formData.pricePer4Hours}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="formTitle">
                            <Form.Label>Ціна за 6 години</Form.Label>
                            <Form.Control
                                type="number"
                                placeholder="Введіть ціну за 6 години"
                                name="pricePer6Hours"
                                value={formData.pricePer6Hours}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="formTitle">
                            <Form.Label>Ціна за 2 години (Вечірній)</Form.Label>
                            <Form.Control
                                type="number"
                                placeholder="Введіть ціну за 2 години"
                                name="pricePer2HoursEvening"
                                value={formData.pricePer2HoursEvening}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="formTitle">
                            <Form.Label>Ціна за 4 години (Вечірній)</Form.Label>
                            <Form.Control
                                type="number"
                                placeholder="Введіть ціну за 4 години"
                                name="pricePer4HoursEvening"
                                value={formData.pricePer4HoursEvening}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="formTitle">
                            <Form.Label>Ціна за 6 години (Вечірній)</Form.Label>
                            <Form.Control
                                type="number"
                                placeholder="Введіть ціну за 6 години"
                                name="pricePer6HoursEvening"
                                value={formData.pricePer6HoursEvening}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        <Button variant="primary" type="submit">
                            Зберегти
                        </Button>
                    </Form>
                </Col>
            </Row>
        </Container>
    );
}

export default PriceForm;