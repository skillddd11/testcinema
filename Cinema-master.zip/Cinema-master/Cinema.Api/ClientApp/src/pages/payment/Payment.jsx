import Header from "../../components/header/Header";
import styles from "./payment.module.css";
import Footer from "../../components/footer/Footer";
import {useParams} from "react-router-dom";
import {useEffect, useMemo, useState} from "react";
import {apiEndpoint} from "../../api";
import DatePicker from 'react-datepicker';
import {Form} from 'react-bootstrap';
import 'react-datepicker/dist/react-datepicker.css';
import Carousel from "react-bootstrap/Carousel";
import {launchError, launchSuccess} from "../../components/layout/Layout";


const Payment = () => {
    const id = useParams().id;
    const hours = useParams().hours;
    const evening = !!useParams().evening;
    const [info, setInfo] = useState({});

    const [selectedDate, setSelectedDate] = useState(null);
    const [selectedHour, setSelectedHour] = useState(null);
    const [reservedDates, setReservedDates] = useState([]);
    const [films, setFilms] = useState([]);
    const [selectedFilm, setSelectedFilm] = useState(null);
    const [index, setIndex] = useState(0);
    const [bar, setBar] = useState(true);
    const [agree, setAgree] = useState(0);
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [price, setPrice] = useState(5000);

    const handleSelect = (selectedIndex) => {
        setSelectedFilm(validFilms[selectedIndex]);
        setIndex(selectedIndex);
    };

    const handleAgree = (event) => {
        if (event.target.checked)
            setAgree(agree + 1);
        else
            setAgree(agree - 1);
    }

    const isHourDisabled = (hour) => {
        if (selectedDate?.getDay() === 0 || selectedDate?.getDay() === 6) {
            if (hour > 3 && hour < 11) {
                return true;
            }
        } else if (hour > 3 && hour < 12)
            return true;

        const dates = reservedDates.filter((disabledDate) =>
            selectedDate &&
            selectedDate.getDate() === new Date(disabledDate.date).getDate() &&
            selectedDate.getMonth() === new Date(disabledDate.date).getMonth() &&
            selectedDate.getFullYear() === new Date(disabledDate.date).getFullYear()
        );

        return dates.some(date => {
            if (date.hour > hour)
                return date.hour < hour + +hours;

            return date.hour + date.hours > hour;
        });
    };

    const isBigger = (date1, date2) => {
        if (!date1 || !date2)
            return true;

        return date1 >= date2;
    }

    const hourOptions = Array.from({length: 24}, (_, i) => ({
        value: i,
        label: i < 10 ? `0${i}:00` : `${i}:00`
    }));

    useEffect(() => {
        apiEndpoint('main/payment').fetchById(id)
            .then(res => {
                setInfo(res.data['price']);
                setReservedDates(res.data['reservedDates']);
                setFilms(res.data['films']);
            })
            .catch(err => console.log(err));
    }, [id]);

    const isFormValid = useMemo(() => {
        return selectedDate && selectedHour && agree === 2 && name && email && selectedFilm && info[`pricePer${hours}Hours${evening ? 'Evening' : ''}`];
    }, [selectedDate, selectedHour, agree, name, email, selectedFilm, info, hours, evening]);

    const validFilms = useMemo(() => {
        return films.filter(f => isBigger(new Date(f['endDate']), selectedDate));
    }, [films, selectedDate]);

    const handleSubmit = (e) => {
        e.preventDefault();

        const data = {
            name: name,
            email: email,
            movieId: selectedFilm.id,
            date: selectedDate,
            hour: selectedHour.value,
            evening: evening,
            bar: bar,
            price: info[`pricePer${hours}Hours${evening ? 'Evening' : ''}`],
            priceId: id,
            reservationHours: hours
        }

        apiEndpoint('main/reservation').post(data)
            .then(res => launchSuccess(res))
            .catch(err => launchError(err));
    }

    return (
        <>
            <Header/>
            <div className={styles.wrapper}>
                <main className={styles.content}>
                    <div className={styles.cardPopup}>
                        <div className={styles.cardPopup__container}>
                            <form className={styles.form} onSubmit={handleSubmit}>
                                <div className={styles.form__step}>
                                    <h2 className={'d-flex justify-content-center mb-5'} style={{color: '#c09948'}}>
                                        Аренда зала на {info['hall']?.['capacity']} человека
                                        на {hours} часа {evening ? 'вечером' : 'днем'}
                                    </h2>
                                    <div className="row d-flex justify-content-between mb-5">
                                        <div className="col-md-5">
                                            <div className={'d-flex flex-column'}>
                                                <div className={styles.form__control}>
                                                    <div className={styles.form__holder}>
                                                        <DatePicker
                                                            selected={selectedDate}
                                                            onChange={(date) => {
                                                                setSelectedDate(date);
                                                                setIndex(0);
                                                            }}
                                                            className={styles.form__input}
                                                            minDate={new Date()}
                                                            value={selectedDate ? selectedDate.toLocaleDateString() : ''}
                                                            placeholderText={' '}
                                                        />
                                                        <Form.Label
                                                            className={`${styles.form__placeholder} ${selectedDate && styles.active}`}>
                                                            Дата сеанса
                                                        </Form.Label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-md-5">
                                            <div className={'d-flex flex-column'}>
                                                <div className={styles.form__control}>
                                                    <div className={styles.form__holder}>
                                                        <Form.Select
                                                            value={selectedDate && selectedHour ? selectedHour.value : ''}
                                                            className={styles.form__input}
                                                            onChange={(e) => {
                                                                const selectedOption = hourOptions.find(
                                                                    (option) => option.value === parseInt(e.target.value)
                                                                );
                                                                setSelectedHour(selectedOption);
                                                            }}
                                                        >
                                                            {hourOptions.map((option) => (
                                                                !isHourDisabled(option.value) &&
                                                                <option key={option.value} value={option.value}>
                                                                    {option.label}
                                                                </option>
                                                            ))}
                                                        </Form.Select>
                                                        <Form.Label
                                                            className={`${styles.form__placeholder} ${selectedHour && styles.active}`}>
                                                            Время сеанса
                                                        </Form.Label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <Carousel activeIndex={index} onSelect={handleSelect} interval={null}
                                              className={`mb-5 ${styles.wrap}`} style={{zIndex: 0}}>
                                        {
                                            validFilms.map((item) =>
                                                <Carousel.Item key={'carousel' + item.title}>
                                                    <div className={`row pb-5`}>
                                                        <div
                                                            className={'col-4 d-flex flex-column gap-3'}>
                                                            <img src={item['imageUrl']}
                                                                 alt={""} className={styles.carrouselItem}/>
                                                            <div className={'d-flex justify-content-between'}>
                                                                <p className={styles.itemCaption}>{item.genre} {item.duration}</p>
                                                                <p className={styles.itemCaption}>{item.ageFrom}</p>
                                                            </div>
                                                        </div>
                                                        <div className={'col-8 d-flex flex-column gap-5'}>
                                                            <div>
                                                                <div className={styles.itemText}>{item.title}</div>
                                                                <div
                                                                    className={styles.itemDesc}>{item['description']}</div>
                                                            </div>
                                                            <div>
                                                                <div
                                                                    className={'row align-items-center'}>
                                                                    <div className={'col-6 gap-3 d-flex flex-column'}>
                                                                        <div
                                                                            className={'d-flex flex-wrap align-items-center gap-2'}>
                                                                            Страна
                                                                            <div
                                                                                className={styles.p}>{item.country}</div>
                                                                        </div>
                                                                        <div
                                                                            className={'d-flex flex-wrap align-items-center gap-2'}>
                                                                            Режиссер
                                                                            <div
                                                                                className={styles.p}>{item.director}</div>
                                                                        </div>
                                                                        <div
                                                                            className={'d-flex flex-wrap align-items-center gap-2'}>
                                                                            Сценарий
                                                                            <div
                                                                                className={styles.p}>{item.scenarist}</div>
                                                                        </div>
                                                                        <div
                                                                            className={'d-flex flex-wrap align-items-center gap-2'}>
                                                                            В прокате
                                                                            <div className={styles.p}>
                                                                                {new Date(item['startDate']).toLocaleDateString()} - {new Date(item['endDate']).toLocaleDateString()}
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div
                                                                        className={'d-flex flex-wrap align-items-center gap-2 col-6'}>
                                                                        В ролях
                                                                        <div className={styles.p}>{item.actors}</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </Carousel.Item>
                                            )
                                        }
                                    </Carousel>
                                    <div className={styles.form__control}>
                                        <div className={'d-flex justify-content-between'}>
                                            <div className={'d-grid'}>
                                                <div className={'d-flex align-items-center gap-3'}>
                                                    <input type="checkbox" className={styles.form__checkbox}
                                                           placeholder={' '} id={'bar'} checked={bar}
                                                           onChange={e => {
                                                               setBar(e.target.checked);
                                                               setPrice(e.target.checked ? 5000 : 0);
                                                           }}/>
                                                    <label htmlFor={'bar'} className={'flex-wrap d-flex gap-2'}
                                                           style={{fontSize: '16px'}}>
                                                        Бар и закуски
                                                        <div style={{color: '#c09948'}}>
                                                            во время просмотра
                                                        </div>
                                                    </label>
                                                </div>
                                            </div>
                                            <button className={styles.button} type={'submit'}>
                                                Меню
                                            </button>
                                        </div>
                                        <div className={styles.text}>
                                            * Депозит размером 5000 рублей предоставляет доступ к использыванию бара и
                                            кухни нашего ресторана. В случае отмены бронирования есть возможность
                                            возврата
                                        </div>
                                    </div>
                                    <div className={styles.form__control}>
                                        <div className={styles.form__holder}>
                                            <input type="text" className={styles.form__input}
                                                   placeholder={' '} value={name}
                                                   onChange={e => setName(e.target.value)}/>
                                            <span
                                                className={styles.form__placeholder}>Фамилия Имя Отчество</span>
                                        </div>
                                    </div>
                                    <div className={styles.form__control}>
                                        <div className={styles.form__holder}>
                                            <input type="text" className={styles.form__input} value={email}
                                                   placeholder={' '} onChange={e => setEmail(e.target.value)}/>
                                            <span className={styles.form__placeholder}>Email</span>
                                        </div>
                                    </div>
                                    <div className={'d-grid mb-5'}>
                                        <div className={'d-flex align-items-center gap-3'}>
                                            <input type="checkbox" className={styles.form__checkbox}
                                                   placeholder={' '} id={'data'} onChange={handleAgree}/>
                                            <label htmlFor={'data'} className={'flex-wrap d-flex gap-2'}
                                                   style={{fontSize: '16px'}}>
                                                Я соглашаюсь
                                                <span style={{color: '#c09948'}}>
                                                    на обработку моих персональных данных
                                                </span>
                                            </label>
                                        </div>
                                    </div>
                                    <div className={'d-grid mb-5'}>
                                        <div className={'d-flex align-items-center gap-3'}>
                                            <input type="checkbox" className={styles.form__checkbox}
                                                   placeholder={' '} id={'agree'} onChange={handleAgree}/>
                                            <label htmlFor={'agree'} className={'flex-wrap d-flex gap-2'}
                                                   style={{fontSize: '16px'}}>
                                                Я соглашаюсь
                                                <span style={{color: '#c09948'}}>
                                                    с условиями Договора
                                                </span>
                                            </label>
                                        </div>
                                    </div>
                                    <div className={styles.split}>
                                        <div
                                            className={styles.sum}>{info[`pricePer${hours}Hours${evening ? 'Evening' : ''}`] + price || '-'}</div>
                                        <button className={styles.button} type={'submit'} disabled={!isFormValid}>
                                            Отправить
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </main>
            </div>
            <Footer/>
        </>
    )
}

export default Payment;