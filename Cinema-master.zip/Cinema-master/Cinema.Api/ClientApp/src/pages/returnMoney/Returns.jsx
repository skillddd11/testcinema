import styles from './returns.module.css';
import payment from '../payment/payment.module.css';
import {useNavigate, useParams} from "react-router-dom";
import Header from "../../components/header/Header";
import Footer from "../../components/footer/Footer";
import {useState} from "react";

const Returns = () => {
    const sum = useParams().sum;
    const navigate = useNavigate();

    const [state, setState] = useState();

    return (
        <div className={styles.root}>
            <Header/>
            <main className={styles.main}>
                <div>
                    {
                        sum ?
                            <div className={styles.container}>
                                <span className={`${styles.label} d-flex justify-content-center`} style={{fontSize: 30}}>Введите причину возврата</span>
                                <div className={payment.form__control}>
                                    <div className={payment.form__holder}>
                                        <textarea className={payment.form__input} placeholder={' '} rows={3}/>
                                    </div>
                                </div>
                                <div className={styles.label}>Сумма: {sum} ₽</div>
                                <div>
                                    <button className={styles.button}>оплатить</button>
                                </div>
                            </div>
                            :
                            <div className={styles.container}>
                                <div className={payment.form__control}>
                                    <div className={payment.form__holder}>
                                        <input className={payment.form__input} placeholder={' '} value={state}
                                               onChange={(e) => setState(e.target.value)}/>
                                        <span className={payment.form__placeholder}>Введите суму</span>
                                    </div>
                                </div>
                                <div>
                                    <button className={styles.button} onClick={() => navigate('/returns/' + state)}>
                                        получить сылку
                                    </button>
                                </div>
                            </div>
                    }
                </div>
            </main>
            <Footer/>
        </div>
    )
}

export default Returns;