import {Form} from "react-bootstrap";
import React, {useState} from "react";
import {cities} from "../../api/data";
import {launchSuccess} from "../../components/layout/Layout";

const PickCity = () => {
    const citiesArray = [];
    const [selected, setSelected] = useState('');

    for (const [key] of Object.entries(cities)) {
        citiesArray.push({value: key, label: key});
    }

    const handleChange = (e) => {
        setSelected(e.target.value);

        if (e.target.value !== '') {
            const link = 'https://localhost:44473/' + e.target.value;

            navigator.clipboard.writeText(link)
                .then(() => launchSuccess({data: `Скопировано в буфер обмена (${link})`}));
        }
    }

    return (
        <>
            <div className={'d-flex justify-content-center mt-5 flex-column align-items-center gap-4'}>
                <h1>Выберете город</h1>
                <Form.Group controlId="exampleForm.SelectCustom" className={'w-50'}>
                    <Form.Control as="select" custom onChange={handleChange} value={selected} name={'priceId'}>
                        <option value="" disabled>
                            Выберете город
                        </option>
                        {
                            citiesArray.map((option) => (
                                <option key={option.value} value={option.value}>
                                    {option.label}
                                </option>
                            ))
                        }
                    </Form.Control>
                </Form.Group>
            </div>
        </>
    )
}

export default PickCity;