import styles from './prices.module.css';
import Header from "../../components/header/Header";
import Footer from "../../components/footer/Footer";
import {useEffect, useState} from "react";
import {apiEndpoint} from "../../api";
import {useNavigate} from "react-router-dom";

const Prices = () => {
    const [halls, setHalls] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        apiEndpoint('main/prices').fetch()
            .then((res) => setHalls(res.data))
            .catch((err) => console.log(err));
    }, []);

    return (
        <>
            <Header/>
            <div className={styles.wrapper}>
                <main className={styles.content}>
                    <div className={styles.cardPopup}>
                        <div className={styles.title}>Аренда</div>
                        {
                            halls.map((hall, index) =>
                                <div key={index}>
                                    <div className={styles.header}>
                                        <div className={styles.listTitle}>Залы на {hall['capacity']} мест</div>
                                        <div className={styles.priceList__dayWrap}>
                                            <div className={styles.priceList__day}>2 часа</div>
                                            <div className={styles.priceList__day}>4 часа</div>
                                            <div className={styles.priceList__day}>6 часов</div>
                                        </div>
                                    </div>
                                    <div>
                                        <div className={styles.priceList__periodWrapper}>
                                            <div className={styles.priceList__time}>11:00 — 16:55</div>
                                            <div className={styles.priceList__price}>
                                                <div>
                                                    <div className={styles.priceList__num}
                                                         onClick={() => navigate('/payment/' + hall['price'].id + "/2")}>
                                                        {hall['price']['pricePer2Hours'] || '—'}
                                                    </div>
                                                </div>
                                                <div>
                                                    <div className={styles.priceList__num}
                                                         onClick={() => navigate('/payment/' + hall['price'].id + "/4")}>
                                                        {hall['price']['pricePer4Hours'] || '—'}
                                                    </div>
                                                </div>
                                                <div>
                                                    <div className={styles.priceList__num}
                                                         onClick={() => navigate('/payment/' + hall['price'].id + "/6")}>
                                                        {hall['price']['pricePer6Hours'] || '—'}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div className={styles.priceList__periodWrapper}>
                                            <div
                                                className={`${styles.priceList__time} ${styles.priceList__timeEvening}`}>
                                                17:00 — 01:30
                                            </div>
                                            <div className={styles.priceList__price}>
                                                <div>
                                                    <div
                                                        onClick={() => navigate('/payment/' + hall['price'].id + "/2/evening")}
                                                        className={`${styles.priceList__num} ${styles.priceList__timeEvening}`}>
                                                        {hall['price']['pricePer2HoursEvening'] || '—'}
                                                    </div>
                                                </div>
                                                <div>
                                                    <div
                                                        onClick={() => navigate('/payment/' + hall['price'].id + "/4/evening")}
                                                        className={`${styles.priceList__num} ${styles.priceList__timeEvening}`}>
                                                        {hall['price']['pricePer4HoursEvening'] || '—'}
                                                    </div>
                                                </div>
                                                <div>
                                                    <div
                                                        onClick={() => navigate('/payment/' + hall['price'].id + "/6/evening")}
                                                        className={`${styles.priceList__num} ${styles.priceList__timeEvening}`}>
                                                        {hall['price']['pricePer6HoursEvening'] || '—'}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <img
                                        className={styles.img}
                                        src={hall.url}
                                        alt="First slide"
                                    />
                                    {
                                        index !== halls.length - 1 &&
                                        <div className={styles.split}></div>
                                    }
                                </div>
                            )
                        }
                    </div>
                </main>
            </div>
            <Footer/>
        </>
    );
}

export default Prices;