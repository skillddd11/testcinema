import Home from "./pages/home/Home";
import About from "./pages/about/About";
import Prices from "./pages/prices/Prices";
import Payment from "./pages/payment/Payment";
import AdminPanel from "./pages/admin/Admin";
import MovieForm from "./pages/admin/MovieForm";
import HallForm from "./pages/admin/HallForm";
import Login from "./pages/login/Login";
import PriceForm from "./pages/admin/PriceForm";
import Returns from "./pages/returnMoney/Returns";
import PickCity from "./pages/returnMoney/PickCity";

const AppRoutes = [
    {
        path: '/:id?',
        element: <Home/>
    },
    {
        path: '/about/:param?',
        element: <About/>
    },
    {
        path: '/prices',
        element: <Prices/>
    },
    {
        path: '/payment/:id/:hours/:evening?',
        element: <Payment/>
    },
    {
        path: '/admin/:page?',
        element: <AdminPanel/>
    },
    {
        path: '/admin/movie/:id?',
        element: <MovieForm/>
    },
    {
        path: '/admin/hall/:id?',
        element: <HallForm/>
    },
    {
        path: '/admin/price/:id?',
        element: <PriceForm/>
    },
    {
        path: '/admin/login',
        element: <Login/>
    },
    {
        path: '/returns/:sum?',
        element: <Returns/>
    },
    {
        path: '/pick-city',
        element: <PickCity/>
    },
    {
        path: '*',
        element: <h1>Not Found</h1>
    }
];

export default AppRoutes;
