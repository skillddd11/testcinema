import React from 'react';
import {Route, Routes} from 'react-router-dom';
import AppRoutes from './AppRoutes';
import './custom.css';
import Layout from "./components/layout/Layout";
import AdminLayout from "./components/layout/AdminLayout";

export const App = () => {
    const isAdmin = window.location.pathname.includes('admin');

    if (window.location.pathname.includes('returns'))
        return (
            <Routes>
                {
                    AppRoutes.map((route, index) => {
                        const {element, ...rest} = route;
                        return <Route key={index} {...rest} element={element}/>;
                    })
                }
            </Routes>
        );

    if (isAdmin) {
        return (
            <AdminLayout>
                <Routes>
                    {
                        AppRoutes.map((route, index) => {
                            const {element, ...rest} = route;
                            return <Route key={index} {...rest} element={element}/>;
                        })
                    }
                </Routes>
            </AdminLayout>
        );
    }
    return (
        <Layout>
            <Routes>
                {
                    AppRoutes.map((route, index) => {
                        const {element, ...rest} = route;
                        return <Route key={index} {...rest} element={element}/>;
                    })
                }
            </Routes>
        </Layout>
    );
}

export default App;