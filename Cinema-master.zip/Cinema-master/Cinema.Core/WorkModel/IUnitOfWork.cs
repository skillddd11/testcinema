using DataAccess.Repositories.HallRepository;
using DataAccess.Repositories.MovieRepository;
using DataAccess.Repositories.PriceRepository;

namespace Cinema.Core.WorkModel;

public interface IUnitOfWork : IDisposable
{
    IMovieRepository MovieRepository { get; }
    IHallRepository HallRepository { get; }
    IPriceRepository PriceRepository { get; }

    Task<int> SaveChangesAsync();
}
