using DataAccess;
using DataAccess.Repositories.HallRepository;
using DataAccess.Repositories.MovieRepository;
using DataAccess.Repositories.PriceRepository;

namespace Cinema.Core.WorkModel;

public sealed class UnitOfWork : IUnitOfWork
{
    private readonly CinemaDbContext _context;

    public IMovieRepository MovieRepository { get; }
    public IHallRepository HallRepository { get; }
    public IPriceRepository PriceRepository { get; }

    public UnitOfWork(CinemaDbContext context)
    {
        _context = context;
        MovieRepository = new MovieRepository(_context);
        HallRepository = new HallRepository(_context);
        PriceRepository = new PriceRepository(_context);
    }

    public Task<int> SaveChangesAsync()
    {
        return _context.SaveChangesAsync();
    }

    private bool _disposed;

    private void Dispose(bool disposing)
    {
        if (!_disposed)
        {
            if (disposing)
            {
                _context.Dispose();
            }
        }

        _disposed = true;
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
}
