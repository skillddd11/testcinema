using DataAccess.ResponseDto;

namespace Cinema.Core.Interfaces;

using Microsoft.AspNetCore.Http;

public interface IStorageService
{
    Task<BlobResponseDto> UploadAsyncToStorage(IFormFile file);
    Task<BlobResponseDto> DeleteAsyncFromStorage(string blobFilename);
}
