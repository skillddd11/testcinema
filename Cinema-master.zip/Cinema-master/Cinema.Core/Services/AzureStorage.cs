using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Cinema.Core.Interfaces;
using DataAccess.ResponseDto;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

namespace Cinema.Core.Services;

public class AzureStorage : IStorageService
{
    private BlobContainerClient Container { get; }

    public AzureStorage(IConfiguration configuration)
    {
        Container = new BlobContainerClient(configuration.GetConnectionString("AzureStorageConnection"), "movieimages");

        Container.CreateIfNotExistsAsync();
        Container.SetAccessPolicyAsync(PublicAccessType.Blob);
    }

    public async Task<BlobResponseDto> UploadAsyncToStorage(IFormFile file)
    {
        BlobResponseDto response = new();

        BlobClient client = Container.GetBlobClient("image_" + Guid.NewGuid());

        while (await client.ExistsAsync())
        {
            var formFile = new FormFile(file.OpenReadStream(), 0, file.Length, file.Name, "image_" + Guid.NewGuid());

            file = formFile;
            client = Container.GetBlobClient(file.FileName);
        }

        await using (Stream data = file.OpenReadStream())
            await client.UploadAsync(data);

        response.Status = $"File {file.FileName} Uploaded Successfully";
        response.Error = false;
        response.Blob.Uri = client.Uri.AbsoluteUri;
        response.Blob.Name = client.Name;

        return response;
    }

    public async Task<BlobResponseDto> DeleteAsyncFromStorage(string blobFilename)
    {
        BlobClient file = Container.GetBlobClient(blobFilename);

        if (!await file.DeleteIfExistsAsync())
            return new BlobResponseDto { Error = true, Status = $"File with name {blobFilename} not found." };

        return new BlobResponseDto { Error = false, Status = $"File: {blobFilename} has been successfully deleted." };
    }
}
