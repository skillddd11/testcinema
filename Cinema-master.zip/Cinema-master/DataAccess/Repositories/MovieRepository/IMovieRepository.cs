using DataAccess.Models;

namespace DataAccess.Repositories.MovieRepository;

public interface IMovieRepository
{
    Task<IEnumerable<Movie>> GetMoviesAsync();
    Task<IEnumerable<Movie>> GetActualMoviesAsync();
    Task<Movie?> GetMovieByIdAsync(int id);
    Task<Movie> AddAsync(Movie movie);
    Task<Movie> UpdateAsync(Movie movie);
    Task DeleteAsync(Movie movie);
}
