using DataAccess.Models;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories.MovieRepository;

public class MovieRepository : IMovieRepository
{
    private readonly CinemaDbContext _context;

    public MovieRepository(CinemaDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Movie>> GetMoviesAsync()
    {
        return await _context.Movies.ToListAsync();
    }

    public async Task<IEnumerable<Movie>> GetActualMoviesAsync()
    {
        return await _context.Movies
            .Where(x => x.EndDate >= DateTime.Now)
            .OrderByDescending(x => x.StartDate)
            .ToListAsync();
    }

    public async Task<Movie?> GetMovieByIdAsync(int id)
    {
        return await _context.Movies.FindAsync(id);
    }

    public async Task<Movie> AddAsync(Movie movie)
    {
        await _context.Movies.AddAsync(movie);

        return movie;
    }

    public async Task<Movie> UpdateAsync(Movie movie)
    {
        await Task.Run(() => _context.Movies.Update(movie));

        return movie;
    }

    public async Task DeleteAsync(Movie movie)
    {
        await Task.Run(() => _context.Movies.Remove(movie));
    }
}
