using DataAccess.Models;

namespace DataAccess.Repositories.HallRepository;

public interface IHallRepository
{
    Task<IEnumerable<Hall>> GetAllAsync();
    Task<Hall?> GetByIdAsync(int id);
    Task<Hall> AddAsync(Hall hall);
    Task<Hall> UpdateAsync(Hall hall);
    Task DeleteAsync(Hall hall);

    Task<Price?> GetPriceInfoAsync(int priceId);
    Task AddReservationAsync(Reservation reservation);
    Task<IEnumerable<Hall>> GetHallsByCapacity(Price price);
}
