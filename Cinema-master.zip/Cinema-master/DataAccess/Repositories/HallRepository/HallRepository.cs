using DataAccess.Models;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories.HallRepository;

public class HallRepository : IHallRepository
{
    private readonly CinemaDbContext _context;

    public HallRepository(CinemaDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Hall>> GetAllAsync()
    {
        return await _context.Halls
            .Include(x => x.Price)
            .ToListAsync();
    }

    public async Task<Hall?> GetByIdAsync(int id)
    {
        return await _context.Halls
            .Include(x => x.Price)
            .FirstOrDefaultAsync(h => h.Id == id);
    }

    public async Task<Hall> AddAsync(Hall hall)
    {
        await _context.Halls.AddAsync(hall);

        return hall;
    }

    public async Task<Hall> UpdateAsync(Hall hall)
    {
        await Task.Run(() => _context.Halls.Update(hall));

        return hall;
    }

    public async Task DeleteAsync(Hall hall)
    {
        await Task.Run(() => _context.Halls.Remove(hall));
    }

    public async Task<Price?> GetPriceInfoAsync(int priceId)
    {
        return await _context.Prices
            .Include(p => p.Hall)
            .ThenInclude(h => h!.Reservations.Where(r => r.ReservationDate > DateTime.UtcNow))
            .FirstOrDefaultAsync(p => p.Id == priceId);
    }

    public async Task<IEnumerable<Hall>> GetHallsByCapacity(Price price)
    {
        return await _context.Halls
            .Include(x => x.Price)
            .Include(x => x.Reservations)
            .ToListAsync();
    }

    public async Task AddReservationAsync(Reservation reservation)
    {
        await _context.Reservations.AddAsync(reservation);
    }
}
