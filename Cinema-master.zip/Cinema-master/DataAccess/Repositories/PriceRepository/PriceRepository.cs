using System.Linq.Expressions;
using DataAccess.Models;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories.PriceRepository;

public class PriceRepository : IPriceRepository
{
    private readonly CinemaDbContext _context;

    public PriceRepository(CinemaDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Price>> GetAllAsync()
    {
        return await _context.Prices.ToListAsync();
    }

    public async Task<Price?> GetByIdAsync(int id)
    {
        return await _context.Prices.FindAsync(id);
    }

    public async Task<Price> AddAsync(Price price)
    {
        await _context.Prices.AddAsync(price);
        return price;
    }

    public async Task<Price> UpdateAsync(Price price)
    {
        await Task.Run(() => _context.Prices.Update(price));
        return price;
    }

    public async Task DeleteAsync(Price price)
    {
        await Task.Run(() => _context.Prices.Remove(price));
    }

    public async Task<IEnumerable<Reservation>> GetReservationsAsync(Expression<Func<Reservation, bool>> predicate)
    {
        return await _context.Reservations
            .Where(predicate)
            .Include(r => r.Hall)
            .Include(r => r.Movie)
            .OrderByDescending(r => r.Hour)
            .ToListAsync();
    }
}
