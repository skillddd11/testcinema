using System.Linq.Expressions;
using DataAccess.Models;

namespace DataAccess.Repositories.PriceRepository;

public interface IPriceRepository
{
    Task<IEnumerable<Price>> GetAllAsync();
    Task<Price?> GetByIdAsync(int id);
    Task<Price> AddAsync(Price price);
    Task<Price> UpdateAsync(Price price);
    Task DeleteAsync(Price price);

    Task<IEnumerable<Reservation>> GetReservationsAsync(Expression<Func<Reservation, bool>> predicate);
}
