using DataAccess.Models;
using Microsoft.EntityFrameworkCore;

namespace DataAccess;

public class CinemaDbContext : DbContext
{
    public DbSet<Movie> Movies { get; set; } = null!;
    public DbSet<Hall> Halls { get; set; } = null!;
    public DbSet<Price> Prices { get; set; } = null!;
    public DbSet<Reservation> Reservations { get; set; } = null!;

    public CinemaDbContext(DbContextOptions<CinemaDbContext> options) : base(options)
    {
    }
}
