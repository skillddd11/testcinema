using System.ComponentModel.DataAnnotations;

namespace DataAccess.Models;

public class Reservation
{
    public int Id { get; set; }

    public int HallId { get; set; }
    public Hall? Hall { get; set; }

    public int MovieId { get; set; }
    public Movie? Movie { get; set; }

    public string Name { get; set; } = null!;
    public string Email { get; set; } = null!;
    [DataType(DataType.Date)] public DateTime ReservationDate { get; set; }
    public int Hour { get; set; }
    public int ReservationHours { get; set; }
    public bool Evening { get; set; }
    public bool Bar { get; set; }
    public int Price { get; set; }
}
