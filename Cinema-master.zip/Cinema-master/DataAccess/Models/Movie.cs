using System.ComponentModel.DataAnnotations;

namespace DataAccess.Models;

public class Movie
{
    public int Id { get; set; }

    [MaxLength(50)] public string Title { get; set; } = string.Empty;
    [MaxLength(2000)] public string Description { get; set; } = string.Empty;

    [MaxLength(50)] public string Country { get; set; } = string.Empty;
    [MaxLength(50)] public string Genre { get; set; } = string.Empty;
    [MaxLength(100)] public string Director { get; set; } = string.Empty;
    [MaxLength(200)] public string? Actors { get; set; }
    [MaxLength(50)] public string? Duration { get; set; }
    [MaxLength(50)] public string? Scenarist { get; set; }
    [MaxLength(50)] public string? AgeFrom { get; set; }

    [MaxLength(100)] public string? ImageUrl { get; set; }
    [MaxLength(100)] public string? BlobName { get; set; }

    public bool Premiere { get; set; }
    public bool BigImage { get; set; }
    public bool Avatar { get; set; }

    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
}
