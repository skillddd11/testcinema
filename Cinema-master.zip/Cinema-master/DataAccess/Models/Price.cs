namespace DataAccess.Models;

public class Price
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;

    public int PricePer2Hours { get; set; }
    public int PricePer4Hours { get; set; }
    public int PricePer6Hours { get; set; }

    public int PricePer2HoursEvening { get; set; }
    public int PricePer4HoursEvening { get; set; }
    public int PricePer6HoursEvening { get; set; }

    public Hall? Hall { get; set; }
}
