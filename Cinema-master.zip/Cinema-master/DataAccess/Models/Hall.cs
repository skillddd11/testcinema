namespace DataAccess.Models;

public class Hall
{
    public int Id { get; set; }

    public int Number { get; set; }
    public int Capacity { get; set; }

    public int PriceId { get; set; }
    public Price Price { get; set; } = null!;

    public string Url { get; set; } = null!;
    public string BlobName { get; set; } = null!;

    public ICollection<Reservation> Reservations { get; set; } = null!;
}
